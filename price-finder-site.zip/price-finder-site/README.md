# Price Finder

A simple, free website to look up product prices — no server, no cost.
All product data lives directly inside `products.js`, so the site works
instantly for anyone who visits, with no upload step.

## Files

- `index.html` — the page structure
- `style.css` — all the styling
- `app.js` — search + rendering logic
- `products.js` — **your product data** (edit this whenever prices change)

## How to update your prices

Open `products.js` and edit the list. Each product looks like this:

```js
{ num: "SKU-1001", lineDesc: "Stainless Steel Water Bottle 1L", shortDesc: "Insulated, leak-proof", price: 499 },
```

- `num` → Product Number
- `lineDesc` → Product Line Description
- `shortDesc` → Product Short Description
- `price` → Unit Price (just the number, no ₹ symbol)

Add, remove, or edit rows freely. Keep the commas between rows, and don't
put a comma after the very last row.

**Tip:** Next time your Excel file changes, you can send it to me and I'll
regenerate the whole `products.js` file for you in the right format —
just ask.

## Deploying to GitHub Pages (free hosting)

1. Create a new repository on GitHub (e.g. `price-finder`).
2. Upload all 4 files (`index.html`, `style.css`, `app.js`, `products.js`)
   to the root of that repository.
3. Go to the repo's **Settings → Pages**.
4. Under "Build and deployment", set **Source** to `Deploy from a branch`,
   branch `main`, folder `/ (root)`. Click **Save**.
5. Wait about a minute, then GitHub will give you a live URL like:
   `https://yourusername.github.io/price-finder/`
6. Open that link on your phone and bookmark it (or add it to your home
   screen) for quick access anytime.

Every time you edit `products.js` and push the change to GitHub, the live
site updates automatically within a minute or two.
