// ============================================================
// PRODUCT DATA
// ------------------------------------------------------------
// Replace the sample rows below with your own products.
// Each row needs these 4 fields, matching your Excel columns:
//   num       -> Product Number
//   lineDesc  -> Product Line Description
//   shortDesc -> Product Short Description
//   price     -> Unit Price (just the number, no currency symbol)
//
// Keep the exact format: { num: "...", lineDesc: "...", shortDesc: "...", price: 000 },
// Add or remove as many rows as you need. Don't forget the comma
// between rows, and don't put a comma after the very last row.
// ============================================================

const PRODUCTS = [
  { num: "SKU-1001", lineDesc: "Stainless Steel Water Bottle 1L", shortDesc: "Insulated, leak-proof", price: 499 },
  { num: "SKU-1002", lineDesc: "Cotton Bath Towel Set (2pc)", shortDesc: "600 GSM, soft finish", price: 899 },
  { num: "SKU-1003", lineDesc: "LED Desk Lamp", shortDesc: "Adjustable, USB powered", price: 1299 },
  { num: "SKU-1004", lineDesc: "Ceramic Coffee Mug 350ml", shortDesc: "Microwave safe", price: 249 },
  { num: "SKU-1005", lineDesc: "Wireless Mouse", shortDesc: "2.4GHz, ergonomic design", price: 799 },
  { num: "SKU-1006", lineDesc: "Yoga Mat 6mm", shortDesc: "Non-slip, with carry strap", price: 649 }
];
